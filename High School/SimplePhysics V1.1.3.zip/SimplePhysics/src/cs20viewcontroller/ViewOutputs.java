package cs20viewcontroller;

public class ViewOutputs extends DrawnView {

    public void updateDisplay() {
        jLabel1.setText(this.MyModel.getVarible1Name());
        jLabel2.setText(this.MyModel.getVarible2Name());
        jLabel3.setText(this.MyModel.getVarible3Name());
        jLabel4.setText(this.MyModel.getVarible4Name());
        jLabel5.setText(this.MyModel.getVarible5Name());
    }
    
    public void updateList() {
        answerList.setListData(MyModel.answerList());
    }
    
    public void displayResult() {
        double answer = MyModel.getAnswer();
        String answerStr = Double.toString(answer);
        answerField.setText(answerStr);
        
        if (MyModel.getAnswerType().equals("m/s")){
            answerLabel.setText("Answer(m/s):");
        }
        if (MyModel.getAnswerType().equals("m")){
            answerLabel.setText("Answer(m):");
        }
        if (MyModel.getAnswerType().equals("s")){
            answerLabel.setText("Answer(s):");
        }
        if (MyModel.getAnswerType().equals("Hz")){
            answerLabel.setText("Answer(Hz):");
        }
        if (MyModel.getAnswerType().equals("m/s2")){
            answerLabel.setText("Answer(m/s²):");
        }
        if (MyModel.getAnswerType().equals("kg")){
            answerLabel.setText("Answer(kg):");
        }
        if (MyModel.getAnswerType().equals("J")){
            answerLabel.setText("Answer(J):");
        }
        if (MyModel.getAnswerType().equals("N")){
            answerLabel.setText("Answer(N):");
        }
        if (MyModel.getAnswerType().equals("N/m")){
            answerLabel.setText("Answer(N/m):");
        }
        if (MyModel.getAnswerType().equals("°")){
            answerLabel.setText("Answer(°):");
        }
    }
    
    public void clearDisplay() {
        answerField.setText("0");
        jTextField1.setText("0");
        jTextField2.setText("0");
        jTextField3.setText("0");
        jTextField4.setText("0");
        jTextField5.setText("0");
    }
}

package cs20viewcontroller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * @author Lachlan
 */
public class ViewUserActions extends ViewOutputs {

    private class equalsAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            double var1 = 0;
            double var2 = 0;
            double var3 = 0;
            double var4 = 0;
            double var5 = 0;

            if (jTextField1.getText().equals("?")) {
                var1 = 3.14159265358979323846264345;
            } else {
                var1 = Double.parseDouble(jTextField1.getText());
            }
            if (jTextField2.getText().equals("?")) {
                var2 = 3.14159265358979323846264345;
            } else {
                var2 = Double.parseDouble(jTextField2.getText());
            }
            if (jTextField3.getText().equals("?")) {
                var3 = 3.14159265358979323846264345;
            } else {
                var3 = Double.parseDouble(jTextField3.getText());
            }
            if (jTextField4.getText().equals("?")) {
                var4 = 3.14159265358979323846264345;
            } else {
                var4 = Double.parseDouble(jTextField4.getText());
            }
            if (jTextField5.getText().equals("?")) {
                var5 = 3.14159265358979323846264345;
            } else {
                var5 = Double.parseDouble(jTextField5.getText());
            }

            MyModel.doEquation(var1, var2, var3, var4, var5);
            updateList();
            MyModel.add1();
            displayResult();
        }
    }

    private class kinematics1Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("v = d/t");
            MyModel.setVarible1Name("Velocity (m/s)");
            MyModel.setVarible2Name("Distance (m)");
            MyModel.setVarible3Name("Time (s)");
            MyModel.setVarible4Name("Not used");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }

    private class kinematics2Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("a = v/t");
            MyModel.setVarible1Name("Accelration (m/s²)");
            MyModel.setVarible2Name("Velocity (m/s)");
            MyModel.setVarible3Name("Time (s)");
            MyModel.setVarible4Name("Not used");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }

    private class kinematics3Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("Kinematics 5 vars");
            MyModel.setVarible1Name("Accelration (m/s²)");
            MyModel.setVarible2Name("Vi (m/s)");
            MyModel.setVarible3Name("Vf (m/s)");
            MyModel.setVarible4Name("Distance (m)");
            MyModel.setVarible5Name("Time (s)");
            updateDisplay();
        }
    }

    private class waves1Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("v = fλ");
            MyModel.setVarible1Name("Velocity (m/s)");
            MyModel.setVarible2Name("Frequency (Hz)");
            MyModel.setVarible3Name("Wavelength (m)");
            MyModel.setVarible4Name("Not used");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }

    private class circularMotionAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("Circular Motion");
            MyModel.setVarible1Name("Accelration (m/s²)");
            MyModel.setVarible2Name("Velocity (m/s)");
            MyModel.setVarible3Name("Radius (m)");
            MyModel.setVarible4Name("Period (s)");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }
    
    private class ekAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("ek");
            MyModel.setVarible1Name("Kinetic Energy (J)");
            MyModel.setVarible2Name("Mass (kg)");
            MyModel.setVarible3Name("Velocity (m/s)");
            MyModel.setVarible4Name("Not used");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }
    
    private class epGravAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("epGrav");
            MyModel.setVarible1Name("Potential energy (J)");
            MyModel.setVarible2Name("Mass (kg)");
            MyModel.setVarible3Name("Gravity (m/s²)");
            MyModel.setVarible4Name("Height (m)");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }
    
    private class epElasticAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("epElastic");
            MyModel.setVarible1Name("Potential energy (J)");
            MyModel.setVarible2Name("Spring Constant (N/m)");
            MyModel.setVarible3Name("Displacement (m)");
            MyModel.setVarible4Name("Not used");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }
    
    private class workAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("workFd");
            MyModel.setVarible1Name("Work (J)");
            MyModel.setVarible2Name("Force (N)");
            MyModel.setVarible3Name("Distance (m)");
            MyModel.setVarible4Name("Angle (if used)(°)");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }
    
    private class periodAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("period");
            MyModel.setVarible1Name("Period (s)");
            MyModel.setVarible2Name("Frequency (Hz)");
            MyModel.setVarible3Name("Not used");
            MyModel.setVarible4Name("Not used");
            MyModel.setVarible5Name("Not used");
            updateDisplay();
        }
    }

    private class clearAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyModel.setEquation("");
            MyModel.setVarible1Name("Variable1");
            MyModel.setVarible2Name("Variable2");
            MyModel.setVarible3Name("Variable3");
            MyModel.setVarible4Name("Variable4");
            MyModel.setVarible5Name("Variable5");
            updateDisplay();
            clearDisplay();
            MyModel.clearAll();
        }
    }

    public ViewUserActions() {
        sugoi.addActionListener(new periodAction());
        clearButton.addActionListener(new clearAction());
        equalsButton.addActionListener(new equalsAction());
        kinematics1.addActionListener(new kinematics1Action());
        kinematics2.addActionListener(new kinematics2Action());
        kinematics3.addActionListener(new kinematics3Action());
        waves1.addActionListener(new waves1Action());
        circularMotion.addActionListener(new circularMotionAction());
        ekButton.addActionListener(new ekAction());
        epGravButton.addActionListener(new epGravAction());
        epElasticButton.addActionListener(new epElasticAction());
        workButton.addActionListener(new workAction());         
    }
}

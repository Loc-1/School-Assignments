package cs20models;

/**
 * A class to model the problem or situation your program solves
 *
 * @author Lachlan
 */
public class PhysicsModel {

    public String var1, var2, var3, var4, var5, equationType, answerType;
    public double answer;
    public String[] answerList = new String[1000];
    public int i = 0;

    public PhysicsModel() {
        this.answer = 0.0;
        this.var1 = "";
        this.var2 = "";
        this.var3 = "";
        this.var4 = "";
        this.var5 = "";
        this.equationType = "";
        this.answerType = "";
    }

    public String[] answerList() {
        String answerStr = Double.toString(this.answer);
        if (answerType.equals("m/s")){
            this.answerList[this.i] = answerStr + " (m/s)";
        }
        if (answerType.equals("m")){
            this.answerList[this.i] = answerStr + " (m)";
        }
        if (answerType.equals("s")){
            this.answerList[this.i] = answerStr + " (s)";
        }
        if (answerType.equals("Hz")){
            this.answerList[this.i] = answerStr + " (Hz)";
        }
        if (answerType.equals("m/s2")){
            this.answerList[this.i] = answerStr + " (m/s²)";
        }
        if (answerType.equals("kg")){
            this.answerList[this.i] = answerStr + " (kg)";
        }
        if (answerType.equals("J")){
            this.answerList[this.i] = answerStr + " (J)";
        }
        if (answerType.equals("N")){
            this.answerList[this.i] = answerStr + " (N)";
        }
        if (answerType.equals("N/m")){
            this.answerList[this.i] = answerStr + " (N/m)";
        }
        if (answerType.equals("°")){
            this.answerList[this.i] = answerStr + " (°)";
        }
        
        return this.answerList; 
    }
    
    public void add1() {
        this.i = this.i + 1;
    }

    public double doEquation(double v1, double v2, double v3, double v4, double v5) {
        if (this.equationType.equals("period")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "s";
                return this.answer = 1/v2;
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "Hz";
                return this.answer = 1/v1;
            }
        }
        if (this.equationType.equals("v = d/t")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "m/s";
                return this.answer = v2 / v3;
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "m";
                return this.answer = v1 * v3;
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "s";
                return this.answer = v2 / v1;
            }
        }
        if (this.equationType.equals("a = v/t")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "m/s2";
                return this.answer = v2 / v3;
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "m/s";
                return this.answer = v1 * v3;
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "s";
                return this.answer = v2 / v1;
            }
        }
        if (this.equationType.equals("v = fλ")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "m/s";
                return this.answer = v2 * v3;
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "Hz";
                return this.answer = v1 / v3;
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "m";
                return this.answer = v1 / v2;
            }
        }
        if (this.equationType.equals("Circular Motion")) {
            if (v1 == 3.14159265358979323846264345 && v4 == 0) {
                this.answerType = "m/s2";
                return this.answer = (v2 * v2) / (v3);
            }
            if (v1 == 3.14159265358979323846264345 && v2 == 0) {
                this.answerType = "m/s2";
                return this.answer = (4 * Math.pow(Math.PI, 2) * v3) / (v4 * v4);
            }
            if (v2 == 3.14159265358979323846264345 && v4 == 0) {
                this.answerType = "m/s";
                return this.answer = Math.sqrt(v1 * v3);
            }
            if (v2 == 3.14159265358979323846264345 && v1 == 0) {
                this.answerType = "m/s";
                return this.answer = (2 * Math.PI * v3) / (v4);
            }
            if (v3 == 3.14159265358979323846264345 && v4 == 0) {
                this.answerType = "m";
                return this.answer = (v2 * v2) / v1;
            }
            if (v3 == 3.14159265358979323846264345 && v1 == 0) {
                this.answerType = "m";
                return this.answer = (v2 * v4) / (2 * Math.PI);
            }
            if (v4 == 3.14159265358979323846264345 && v1 == 0) {
                this.answerType = "s";
                return this.answer = (2 * Math.PI * v3) / (v2);
            }
            if (v4 == 3.14159265358979323846264345 && v2 == 0) {
                this.answerType = "s";
                return this.answer = Math.sqrt((4 * Math.pow(Math.PI, 2) * v3) / (v1));
            }
        }
        if (this.equationType.equals("Kinematics 5 vars")) {
            if (v1 == 3.14159265358979323846264345 && v4 == 0) {
                this.answerType = "m/s2";
                //a = Vf-Vi/t
                return this.answer = (v3 - v2) / (v5);
            }
            if (v1 == 3.14159265358979323846264345 && v5 == 0) {
                this.answerType = "m/s2";
                //Vf2 = Vi2 + 2ad
                return this.answer = ((v3 * v3) - (v2 * v2)) / (2 * v4);
            }
            if (v1 == 3.14159265358979323846264345 && v3 == 0) {
                this.answerType = "m/s2";
                return this.answer = 2 * ((v4) - (v2 * v5)) / (v5 * v5);
            }
            if (v1 == 3.14159265358979323846264345 && v2 == 0) {
                this.answerType = "m/s2";
                return this.answer = (2 * ((v4) - (v3 * v5)) / (v5 * v5)) * -1;
            }
            if (v2 == 3.14159265358979323846264345 && v5 == 0) {
                this.answerType = "m/s";
                //Vf2 = Vi2 + 2ad
                return this.answer = Math.sqrt((v3 * v3) - (2 * v1 * v4));
            }
            if (v2 == 3.14159265358979323846264345 && v4 == 0) {
                //a = Vf-Vi/t
                this.answerType = "m/s";
                return this.answer = ((v1 * v5) - v3) * -1;
            }
            if (v2 == 3.14159265358979323846264345 && v3 == 0) {
                this.answerType = "m/s";
                return this.answer = ((v4) - (0.5 * v1 * (v5 * v5))) / v5;
            }
            if (v2 == 3.14159265358979323846264345 && v1 == 0) {
                //d = (Vf-Vi/2)t
                this.answerType = "m/s";
                return this.answer = ((2 * v4) / (v5)) - v3;
            }
            if (v3 == 3.14159265358979323846264345 && v4 == 0) {
                //a = Vf-Vi/t
                this.answerType = "m/s";
                return this.answer = (v1 * v5) + v2;
            }
            if (v3 == 3.14159265358979323846264345 && v5 == 0) {
                //Vf2 = Vi2 + 2ad
                this.answerType = "m/s";
                return this.answer = Math.sqrt((v2 * v2) + (2 * v1 * v4));
            }
            if (v3 == 3.14159265358979323846264345 && v1 == 0) {
                //d = (Vf-Vi/2)t
                this.answerType = "m/s";
                return this.answer = ((2 * v4) / v5) - v2;
            }
            if (v3 == 3.14159265358979323846264345 && v2 == 0) {
                this.answerType = "m/s";
                return this.answer = ((v4) + (0.5 * v1 * (v5 * v5))) / v5;
            }
            if (v4 == 3.14159265358979323846264345 && v1 == 0) {
                //d = (Vf-Vi/2)t
                this.answerType = "m";
                return this.answer = ((v3 + v2) / 2) * v5;
            }
            if (v4 == 3.14159265358979323846264345 && v5 == 0) {
                //Vf2 = Vi2 + 2ad
                this.answerType = "m";
                return this.answer = ((v3 * v3) - (v2 * v2)) / (2 * v1);
            }
            if (v4 == 3.14159265358979323846264345 && v2 == 0) {
                this.answerType = "m";
                return this.answer = (v3 * v5) - (0.5 * v1 * (v5 * v5));
            }
            if (v4 == 3.14159265358979323846264345 && v3 == 0) {
                this.answerType = "m";
                return this.answer = (v2 * v5) + (0.5 * v1 * (v5 * v5));
            }
            if (v5 == 3.14159265358979323846264345 && v4 == 0) {
                //a = Vf-Vi/t
                this.answerType = "s";
                return this.answer = (v3 - v2) / v1;
            }
            if (v5 == 3.14159265358979323846264345 && v1 == 0) {
                //d = (Vf-Vi/2)t
                this.answerType = "s";
                return this.answer = (v4) / ((v2 + v3) / 2);
            }
            if (v5 == 3.14159265358979323846264345 && v3 == 0) {
                this.answerType = "s";
                double vf = Math.sqrt((v2 * v2) + (2 * v1 * v4));
                return this.answer = (vf - v2) / v1;
            }
            if (v5 == 3.14159265358979323846264345 && v2 == 0) {
                this.answerType = "s";
                double vi = Math.sqrt((v3 * v3) - (2 * v1 * v4));
                return this.answer = (v3 - vi) / v1;
            }
        }
        if (this.equationType.equals("ek")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "J";
                return this.answer = (0.5 * v2 * (v3 * v3));
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "kg";
                return this.answer = (2 * v1) / (v3 * v3);
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "m/s";
                return this.answer = Math.sqrt((2 * v1) / (v2));
            }
        }
        if (this.equationType.equals("epGrav")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "J";
                return this.answer = (v2 * v3 * v4);
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "kg";
                return this.answer = v1 / (v3 * v4);
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "m/s2";
                return this.answer = v1 / (v2 * v4);
            }
            if (v4 == 3.14159265358979323846264345) {
                this.answerType = "m";
                return this.answer = v1 / (v2 * v3);
            }
        }
        if (this.equationType.equals("epElastic")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "J";
                return this.answer = (0.5 * v2 * (v3 * v3));
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "N/m";
                return this.answer = (2 * v1) / (v3 * v3);
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "m";
                return this.answer = Math.sqrt((2 * v1) / v2);
            }
        }
        if (this.equationType.equals("workFd")) {
            if (v1 == 3.14159265358979323846264345) {
                this.answerType = "J";
                double v4true = Math.toRadians(v4);
                return this.answer = (v2 * v3 * Math.cos(v4true));
            }
            if (v2 == 3.14159265358979323846264345) {
                this.answerType = "N";
                double v4true = Math.toRadians(v4);
                return this.answer = (v1 / (v3 * Math.cos(v4true)));
            }
            if (v3 == 3.14159265358979323846264345) {
                this.answerType = "m";
                double v4true = Math.toRadians(v4);
                return this.answer = v1 / (v2 * Math.cos(v4true));
            }
            if (v4 == 3.14159265358979323846264345) {
                this.answerType = "°";
                double answer = (v1 / (v2 * v3));
                return this.answer = Math.toDegrees(Math.acos(answer));
            }
        }
// a = Vf-Vi/t     Works!!
//Vf2 = Vi2 + 2ad  Works!!
//d = (Vf-Vi/2)t   Works!!
//d = Vit + 1/2at2 Works!!
//d = Vft - 1/2at2 Works!!
// http://resource.rockyview.ab.ca/rvlc/physics30_BU/course_documents/Physics%2030%20%20formula%20sheet%20New.pdf
        return 0.0;
    }

    public String getAnswerType() {
        return this.answerType;
    }

    public void setEquation(String s) {
        this.equationType = s;
    }

    public String getEquation() {
        return this.equationType;
    }

    public void setAnswer(double d) {
        this.answer = d;
    }

    public double getAnswer() {
        return this.answer;
    }

    public String getVarible1Name() {
        return this.var1;
    }

    public void setVarible1Name(String d) {
        this.var1 = d;
    }

    public String getVarible2Name() {
        return this.var2;
    }

    public void setVarible2Name(String d) {
        this.var2 = d;
    }

    public String getVarible3Name() {
        return this.var3;
    }

    public void setVarible3Name(String d) {
        this.var3 = d;
    }

    public String getVarible4Name() {
        return this.var4;
    }

    public void setVarible4Name(String d) {
        this.var4 = d;
    }

    public String getVarible5Name() {
        return this.var5;
    }

    public void setVarible5Name(String d) {
        this.var5 = d;
    }

    public void clearAll() {
        this.answer = 0.0;
        this.var1 = "";
        this.var2 = "";
        this.var3 = "";
        this.var4 = "";
        this.var5 = "";
        this.equationType = "";
        this.answerType = "";
    }

}

package elevenslab;

public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
            String ranks[] = {"Ace", "Two", "Three","Four","Five","Six","Seven"};
            String suits[] = {"Clubs", "Spades", "Hearts", "Diamonds"};
            int values[] = {1,2,3,4,5,6,7};
            Deck deck1 = new Deck(ranks,suits,values);
            
            System.out.println(deck1.toString());
	}
}

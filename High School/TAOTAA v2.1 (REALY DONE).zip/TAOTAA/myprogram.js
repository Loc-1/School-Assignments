// Programmer's Name: Lachlan
// Program Name: The Adventures of the Anonymous Alligator Version 2.0
////////////////////////////////////////////////////////////////////////////

load("cs10-txt-lib-0.1.js");
// Don't edit the line above, or you won't be able to get user input!

// Also, do not use the following variable names in your own code below:
//    load, print, getInput, javaSleep, getWorkingDirectory, openFile, hasNextLine, getNextLine

// Write your program below this line:
// ***********************************

// LOADING SCREEN ANIMATIONS

var spacer = "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"
print(spacer);
print("                     _  _");
print("                    / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("           .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("          (    `      ,           \\             |    _    ^^-._");
print("           Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("            `--------`       /  /                >  >        _`)  )");
print("                            (((`                (((`        `'--'^");
print("Loading");
javaSleep(250);
print(spacer);
print("                     _  _");
print("                    / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("           .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("          (    `      ,           \\             |    _    ^^-._");
print("           Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("            `--------`     /  /                >  >          _`)  )");
print("                         (((`                (((`           `'--'^");
print("Loading.");
javaSleep(250);
print(spacer);
print("                    _  _");
print("                   / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("          .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("         (    `      ,           \\             |    _    ^^-._");
print("          Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("           `--------`       /  /                >  >        _`)  )");
print("                           (((`                (((`        `'--'^");
print("Loading..");
javaSleep(250);
print(spacer);
print("                    _  _");
print("                   / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("          .OO.----'\\-/\\-/   `-'                /^  ^^-._");
print("         (    `      ,           \\             |    _    ^^-._");
print("          Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("           `--------`     /  /                >  >          _`)  )");
print("                        (((`                (((`           `'--'^");
print("Loading...");
javaSleep(250);
print(spacer);
print("                   _  _");
print("                  / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("         .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("        (    `      ,           \\             |    _    ^^-._");
print("         Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("          `--------`       /  /                >  >        _`)  )");
print("                          (((`                (((`        `'--'^");
print("Loading");
javaSleep(250);
print(spacer);
print("                   _  _");
print("                  / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("         .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("        (    `      ,           \\             |    _    ^^-._");
print("         Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("          `--------`     /  /                >  >          _`)  )");
print("                       (((`                (((`           `'--'^");
print("Loading.");
javaSleep(250);
print(spacer);
print("                  _  _");
print("                 / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("        .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("       (    `      ,           \\             |    _    ^^-._");
print("        Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("         `--------`       /  /                >  >        _`)  )");
print("                         (((`                (((`        `'--'^");
print("Loading..");
javaSleep(250);
print(spacer);
print("                  _  _");
print("                 / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("        .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("       (    `      ,           \\             |    _    ^^-._");
print("        Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("         `--------`     /  /                >  >          _`)  )");
print("                      (((`                (((`           `'--'^");
print("Loading...");
javaSleep(250);
print(spacer);
print("                 _  _");
print("                / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("       .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("      (    `      ,           \\             |    _    ^^-._");
print("       Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("        `--------`       /  /                >  >        _`)  )");
print("                        (((`                (((`        `'--'^");
print("Loading");
javaSleep(250);
print(spacer);
print("                 _  _");
print("                / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("       .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("      (    `      ,           \\             |    _    ^^-._");
print("       Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("        `--------`     /  /                >  >          _`)  )");
print("                     (((`                (((`           `'--'^");
print("Loading.");
javaSleep(250);
print(spacer);
print("                _  _");
print("               / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("      .OO.----'\\-/\\-/   `-'                /^  ^^-._");
print("     (    `      ,           \\             |    _    ^^-._");
print("      Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("       `--------`       /  /                >  >        _`)  )");
print("                       (((`                (((`        `'--'^");
print("Loading..");
javaSleep(250);
print(spacer);
print("                _  _");
print("               / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("      .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("     (    `      ,           \\             |    _    ^^-._");
print("      Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("       `--------`     /  /                >  >          _`)  )");
print("                    (((`                (((`           `'--'^");
print("Loading...");
javaSleep(250);
print(spacer);
print("               _  _");
print("              / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("     .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("    (    `      ,           \\             |    _    ^^-._");
print("     Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("      `--------`       /  /                >  >        _`)  )");
print("                      (((`                (((`        `'--'^");
print("Loading");
javaSleep(250);
print(spacer);
print("               _  _");
print("              / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("     .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("    (    `      ,           \\             |    _    ^^-._");
print("     Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("      `--------`     /  /                >  >          _`)  )");
print("                   (((`                (((`           `'--'^");
print("Loading.");
javaSleep(250);
print(spacer);
print("              _  _");
print("             / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("    .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("   (    `      ,           \\             |    _    ^^-._");
print("    Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("     `--------`       /  /                >  >        _`)  )");
print("                     (((`                (((`        `'--'^");
print("Loading..");
javaSleep(250);
print(spacer);
print("              _  _");
print("             / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("    .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("   (    `      ,           \\             |    _    ^^-._");
print("    Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("     `--------`     /  /                >  >          _`)  )");
print("                  (((`                (((`           `'--'^");
print("Loading...");
javaSleep(250);
print(spacer);
print("             _  _");
print("            / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("   .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("  (    `      ,           \\             |    _    ^^-._");
print("   Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("    `--------`       /  /                >  >        _`)  )");
print("                    (((`                (((`        `'--'^");
print("Loading");
javaSleep(250);
print(spacer);
print("             _  _");
print("            / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("   .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("  (    `      ,           \\             |    _    ^^-._");
print("   Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("    `--------`     /  /                >  >          _`)  )");
print("                 (((`                (((`           `'--'^");
print("Loading.");
javaSleep(250);
print(spacer);
print("            _  _");
print("           / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("  .OO.----'\\-/\\-/   `-'                /^  ^^-._");
print(" (    `      ,           \\             |    _    ^^-._");
print("  Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("   `--------`       /  /                >  >        _`)  )");
print("                   (((`                (((`        `'--'^");
print("Loading..");
javaSleep(250);
print(spacer);
print("            _  _");
print("           / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print("  .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print(" (    `      ,           \\             |    _    ^^-._");
print("  Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("   `--------`     /  /                >  >          _`)  )");
print("                (((`                (((`           `'--'^");
print("Loading...");
javaSleep(250);
print(spacer);
print("           _  _");
print("          / \\/ \\-._   _.-'^'^^'^^'^^ ^^'-.");
print(" .OO.----'\\0/\\0/   `-'                /^  ^^-._");
print("(    `      ,           \\             |    _    ^^-._");
print(" Vv--vv-Vv-`___...)_/  /_/_/_/_/_/_/_/\\  (__________^^-.");
print("  `--------`       /  /                >  >        _`)  )");
print("                  (((`                (((`        `'--'^");
print("Loading");
javaSleep(250);
print(spacer);
print("W");
javaSleep(50);
print(spacer);
print("We");
javaSleep(50);
print(spacer);
print("Wel");
javaSleep(50);
print(spacer);
print("Welc");
javaSleep(50);
print(spacer);
print("Welco");
javaSleep(50);
print(spacer);
print("Welcom");
javaSleep(50);
print(spacer);
print("Welcome");
javaSleep(50);
print(spacer);
print("Welcome t");
javaSleep(50);
print(spacer);
print("Welcome to");
javaSleep(50);
print(spacer);
print("Welcome to T");
javaSleep(50);
print(spacer);
print("Welcome to Th");
javaSleep(50);
print(spacer);
print("Welcome to The");
javaSleep(50);
print(spacer);
print("Welcome to The A");
javaSleep(50);
print(spacer);
print("Welcome to The Ad");
javaSleep(50);
print(spacer);
print("Welcome to The Adv");
javaSleep(50);
print(spacer);
print("Welcome to The Adve");
javaSleep(50);
print(spacer);
print("Welcome to The Adven");
javaSleep(50);
print(spacer);
print("Welcome to The Advent");
javaSleep(50);
print(spacer);
print("Welcome to The Adventu");
javaSleep(50);
print(spacer);
print("Welcome to The Adventur");
javaSleep(50);
print(spacer);
print("Welcome to The Adventure");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures o");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of T");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of Th");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The A");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The An");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Ano");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anon");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anony");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonym");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymo");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymou");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous A");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Al");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous All");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Alli");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Allig");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Alliga");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Alligat");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Alligato");
javaSleep(50);
print(spacer);
print("Welcome to The Adventures of The Anonymous Alligator");
javaSleep(1000);
print(spacer);
print("W");
javaSleep(50);
print(spacer);
print("Wh");
javaSleep(50);
print(spacer);
print("Wha");
javaSleep(50);
print(spacer);
print("What");
javaSleep(50);
print(spacer);
print("What i");
javaSleep(50);
print(spacer);
print("What is");
javaSleep(50);
print(spacer);
print("What is y");
javaSleep(50);
print(spacer);
print("What is yo");
javaSleep(50);
print(spacer);
print("What is you");
javaSleep(50);
print(spacer);
print("What is your");
javaSleep(50);
print(spacer);
print("What is your n");
javaSleep(50);
print(spacer);
print("What is your na");
javaSleep(50);
print(spacer);
print("What is your nam");
javaSleep(50);
print(spacer);
print("What is your name");
javaSleep(50);
print(spacer);
print("What is your name?");
javaSleep(50);

//GAME LOOP

var gameOver = false
var location = "start"
var brother1 = false
var brother2 = false
var userInput
// Random Var number
var random = Math.floor(Math.random()* 10 + 1);

var  userName = getInput();
print("So your name is " +userName);
if(userName == "Lisa" || userName == "Bill" || userName == "Laura"){
    print("That is a great name!!");
}
if(userName == "Lachlan"){
    // Easter Egg!!!
    load("minigame.js");
}
if(userName == "darth vader" || userName == "star wars" || userName == "luke"){
    print(spacer);
    print("         _.-'~~~~~~`-._");
    print("        /      ||      \\ ");
    print("       /       ||       \\ ");
    print("      |        ||        |");
    print("      | _______||_______ |");
    print("      |/ ----- \\/ ----- \\|");
    print("     /  (    )  (     )  \\ ");
    print("    / \\  ----- () -----  / \\ ");
    print("   /   \\      /||\\      /   \\ ");
    print("  /     \\    /||||\\    /     \\ ");
    print(" /       \\  /||||||\\  /       \\ ");
    print("/_        \\o========o/        _\\ ");
    print("  `--...__|`-._  _.-'|__...--'");
    print("          |    `'    |     ");
    print("   May The force be with you.");
    javaSleep(1500);
    print(spacer);
}

while(gameOver == false){
    if(location == "start"){
        print("You are a baby alligator you just hatched from an egg and don't know were");
        print("you are or where your bothers and mother are.");
        print("Would you like to 1) Follow other egg shells or 2) Look for you mother?");
        userInput =  getInput();
        if(userInput == "1"){
            location = "swamp"
        }
        if(userInput == "2"){
            location = "largeAlligator"
        }
    }
    if(location == "swamp"){
        print("You are in a swamp the trail of egg shells is now gone.");
        print("Go 1) West 2) East or 3) Swim?");
        userInput = getInput();
        if(userInput == "2"){
            location = "eastSwamp"
        }
        if(userInput == "1"){
            location = "westSwamp"
        }
        if(userInput == "3"){
            print("As you are swimming you get your foot caught in some reeds.");
            print("you drown trying to escape.");
            gameOver = true
        }
    }
    if(location == "largeAlligator"){
        print("You come across a large 9 foot male alligator");
        print("do you 1) turn back because of his size or 2) ask him about your mother?");
        userInput = getInput();
        if (userInput == "1"){
            location = "swamp"
        }
        if (userInput == "2"){
            print("The large alligator turns to you yawns and eats you with one large gulp.");
            gameOver = true
        }
    }
    if(location == "eastSwamp"){
        print("You are in the east swamp go 1) West?");
        userInput = getInput();
        if (userInput == "1"){
            location = "swamp"
        }
    }
    if(location == "westSwamp"){
        print("You are in the west swamp go 1) West or 2) East?");
        userInput = getInput();
        if(userInput == "1"){
            location = "farWestSwamp"
        }
        if(userInput == "2"){
            location = "swamp"
        }
    }
    if(location == "farWestSwamp"){
        print("You are in the far west swamp. Your stomach begins to rumble you are");
        print("very hungry. Go 1) west or 2) give up?");
        userInput = getInput();
    
        if(userInput == "1"){
            location = "scraps"
        }
        if(userInput == "2"){
            print("You stay there for many hours till your small body collapses");
            gameOver = true
        }
    }
    if(location == "scraps"){
        if(random < 5){
            print("You come across some scraps of a fish and eat them growing bigger.");
            print("You are no longer hungry.");
            print("Would you know like to go 1) West?");
            userInput = getInput();
            if(userInput == "1"){
                location = "wetlands"
            }
        }
        if(random > 5){
            print("You come across some scraps of a bunny and eat them growing bigger.");
            print("You are no longer hungry.");
            print("Would you know like to go 1) West?");
            userInput = getInput();
            if(userInput == "1"){
                location = "wetlands"
            }
        }
    }
    if(location == "wetlands"){
        print("You are now in some wetlands with still no sign of your family.");
        print("Go 1) West or 2) South?");
        userInput = getInput();
        if(userInput == "1"){
            location = "wetlandsTrap"
        } 
        if(userInput == "2"){
            location = "car"
        }
    }
    if(location == "wetlandsTrap"){
        print("You come across a metal contraption with a fish in it.");
        print("You remember how good the last food was.");
        print("Go 1) Eat the food or 2) Turn back and explore.");
        userInput = getInput();
        if(userInput == "1"){
            location = "stuckInTrap"
        }
        if(userInput == "2"){
            location = "wetlands" 
        }
    }
    if(location == "car"){
        print("You come across a large red object with four circluar objects");
        print("holding it up. Do you 1) Inpsect object 2) Turn back");
        userInput = getInput();
        if(userInput == "1"){
            location = "poachers"
        }
        if(userInput == "2"){
            location = "wetlands"
        }
    }
    if(location =="stuckInTrap"){
        print("The metal object closes on your leg as you take the food.");
        print("You feel a great pain on your leg. It starts to bleed.");
        print("Do you 1) Kick your leg or 2) Make nosie to alert someone?");
        userInput = getInput();
        if(userInput == "1"){
            print("Your leg is in even more pain!");
            print("Do you 1) Kick your leg or 2) Give up?");
            userInput = getInput();
            if(userInput == "1"){
                location = "cave"
            }
            if(userInput == "2"){
                location = "captured"
            }
            
        }
        if(userInput == "2"){
            location = "captured"
        }
    }
    if(location == "poachers"){
        print("You hear noises that you don't understand.");
        print("Do you 1) Attack the source of the noise or 2) Run away?");
        userInput = getInput();
        if(userInput == "1"){
            print("A large beast that walks on two legs is in front of you.")
            print("You attack it.")
            print("A large bang sounds....")
            location = "captured"
        }
        if(userInput == "2"){
            location = "wetlands"
        }
    }
    if(location == "captured"){
        print("You slowly lose consciousness....");
        javaSleep(1500);
        print(spacer)
        print("Welcome to Part 2");
        javaSleep(2500);   
        location = "pen"
    }
    if(location == "cave"){
        print("You find a cave. Your leg is still bleeding.");
        print("Do you 1) Rest in cave or 2) Find a better place to rest?");
        userInput = getInput();
        if(userInput == "1"){
            location = "captured"
        }
        if(userInput == "2"){
            location = "log"
        }
    }
    if(location == "log"){
        print("You find a log. You are in to much pain to continue.");
        print("You lay down and rest hoping for the pain to go away.");
        location = "captured"
    }
    if(location == "pen"){
        print("You awake in a concrete box with a hay bedding in the middle\nand one tunnel that leads to a bright light.");
        print("Your leg no longer hurts. You have to escape but you have a");
        print("feeling your brothers are here too.")
        print("Where are you? 1) Enter tunnel?");
        userInput = getInput();
        if(userInput == "1"){
            print("You exit the tunnel and find yourself in a zoo!");
            location = "northZoo"
        }
    }
    if(location == "northZoo"){
        print("You are in the North Zoo.");
        print("Go 1) South Zoo 2) Vacant pen or 3) Lake?");
        userInput = getInput();
        if(userInput == "1"){
            location = "southZoo"
        }
        if(userInput == "2"){
            location = "vacantPen"
        }
        if(userInput == "3"){
            location = "lake"
        }
    }
    if(location == "southZoo"){
        print("You are in the South Zoo.");
        print("Go 1) North Zoo 2) Lake 3) Loading bay or 4) Feeding Area?");
        userInput = getInput();
        if(userInput == "1"){
            location = "northZoo"
        }
        if(userInput == "2"){
            location = "lake"
        }
        if(userInput == "3"){
            location = "loadingBay"
        }
        if(userInput == "4"){
            location = "feedingArea"
        }
    }
    if(location == "vacantPen"){
        print("You are in a Pen. No one is in it.");
        print("Go 1) North Zoo?");
        userInput = getInput();
        if(userInput == "1"){
            location = "northZoo"
        }
    }
    if(location == "lake"){
        print("You are swiming in a lake with fake logs all around you.");
        print("Go 1) North Zoo 2) South Zoo 3) Viewing Area or 4) Dive under water?");
        userInput = getInput();
        if(userInput == "2"){
            location = "southZoo"
        }
        if(userInput == "1"){
            location = "northZoo"
        }
        if(userInput == "3"){
            location = "viewingArea"
        }
        if(userInput == "4"){
            location = "underwater"
        }
    }
    if(location == "viewingArea"){
        print("You are in the Viewing Area. Many of the gaint beasts are \nlooking at you.");
        print("Go to the 1) Lake?");
        userInput = getInput();
        if(userInput == "1"){
            location = "lake"
        }
    }
    if(location == "underwater"){
        print("You are under water you see another small alligator.");
        print("You aproach the other small alligator and realize that its");
        print("one of your brothers. He tells you that he knows a way out");
        print("through the loading bay but hes looking for your other brother,");
        print("before he tries to escape.");
        brother1 = true
        location = "lake"
    }
    if(location == "feedingArea"){
        print("You are in the feeding area.");
        print("Do you 1) Eat food or 2) go to South Zoo?")
        userInput = getInput();
        if(userInput == "2"){
            location = "southZoo"
        }
        if(userInput == "1")
            location = "brother2"
    }
    if(location == "brother2"){
        print("As you eat the food something behind you taps your back.");
        print("It's your brother! He tells you he got sperated from your");
        print("other brother but he knows he is somewhere in this zoo.");
        brother2 = true
        location = "southZoo"
    }

    if(location == "loadingBay" && brother1 == true && brother2 == true){
        print("Your brother shows you a small cut in the fence.");
        print("You crawl through to the other side with your brothers.");
        print("Your brother shows you a large metal monster with");
        print("crates and barrels in it.");
        print("Do you 1) hide in crates or 2) hide in barrels");
        userInput = getInput();
        if(userInput == "1"){
            print("You and your brothers crawl into the crates together,");
            print(spacer);
            print("Welcome to part 3");
            javaSleep(2500);
            print("You and your brother have escaped the zoo and find yourselfs in");
            print("a bog. Your brothers leave you to go live out there lives but you are");
            print("still looking for your mother.");
            location = "bog"
        }
        if(userInput == "2"){
            print("You and your brothers crawl into the barrel together,");
            print(spacer);
            print("Welcome to part 3");
            javaSleep(2500);
            print("You and your brother have escaped the zoo and find yourselfs in");
            print("a bog. Your brothers leave you to go live out there lives but you are");
            print("still looking for your mother.");
            location = "bog"
        }
        
    }
    if(location == "loadingBay" && brother1 == false){
        print("You have to find your brothers before you can try to escape.");
        location = "southZoo"
    }
    if(location == "loadingBay" && brother2 == false){
        print("You have to find your brothers before you can try to escape.");
        location = "southZoo"
    }
    if(location == "loadingBay" && brother1 == false && brother2 == false){
        print("You have to find your brothers before you can try to escape.");
        location = "southZoo"
    }
    if(location == "bog"){
        print("Go 1) west or 2) east?");
        userInput = getInput();
        if(userInput == "1"){
            location = "westBog"
        }
        if(userInput == "2"){
            location = "eastBog"
        }
    }
    if(location == "westBog"){
        print("You in the West bog.");
        print("Go 1) east?");
        userInput = getInput();
        if(userInput == "1"){
            location = "bog"
        }
    }
    if(location == "eastBog"){
        print("You are in the East bog. There is a trail of blood.");
        print("Do you 1) Inspect the trail of blood or 2) Go west?");
        userInput = getInput();
        if(userInput == "1"){
            location = "blood"
        }
        if(userInput == "2"){
            location = "bog"
        }
    }
    if(location == "blood"){
        print("You Inspect the trail of blood. In goes deeper into the bog.");
        print("Do you 1) Turn back 2) Follow the blood");
        userInput = getInput();
        if(userInput == "1"){
            location = "bog"
        }
        if(userInput == "2"){
            location = "mother"
        }
    }
    if(location == "mother"){
        print("You follow the blood into a bush.");
        print("On the other side of the bush there is a injured alligator.");
        print("Its your Mother! Her wounds are deep and she might not live.");
        print("");
        print("She tells you she was defending of attackers from the eggs.");
        print("You realize that is how you and your brothers got seprated.");
        print("She tells you that she loves you and to go live out your life,");
        print("and not to worry about her any more. And that soon she would");
        print("be in a better place.");
        javaSleep(10000);
        print(spacer);
        print("You leave your mother and head back to the bog.");
        location ="bog2"
    }
    if(location == "bog2"){
        print("You are in the bog.");
        print("Go 1) west 2) east or 3) swim for food?");
        userInput = getInput();
        if(userInput == "1"){
            location = "westBog2"
        }
        if(userInput == "2"){
            location = "eastBog2"
        }
        if(userInput == "3"){
            location = "waterBog"
        }
    }
    if(location == "westBog2"){
        print("You are in the west bog.");
        print("Go 1) east?");
        userInput = getInput();
        if(userInput == "1"){
            location = "bog2"
        }
    }
    if(location == "eastBog2"){
        print("You are in the east bog.");
        print("Go 1) west?");
        userInput = getInput();
        if(userInput == "1"){
            location = "bog2"
        }
    }
    if(location == "waterBog"){
        print("You are swimming in the bog.");
        print("1) dive down 2) go back to land?");
        userInput = getInput();
        if(userInput == "1"){
            location = "underwaterBog"
        }
        if(userInput == "2"){
            location = "bog2"
        }
    }
    if(location == "underwaterBog"){
        print("You dive down under water.");
        print("You see a huge fish grab it up in your mouth");
        print("and bring it to the surface.");
        print("You see an female alligator laying in the sun");
        print("Do you 1) give the fish to her or 2) eat the fish yourself?");
        userInput = getInput();
        if(userInput == "1"){
            print("You give the alligator the fish she thanks you and");
            print("asks you to share it with her.");
            print("You look at her .....");
            location = "love"
        }
        if(userInput == "2"){
            location = "largeAlligator2"
        }
    }
    if(location == "love"){
        javaSleep(5000);
        print(spacer);
        print("1 year later...");
        location = "family"
    }
    if(location == "largeAlligator2"){
        print("You eat your fish and come across a larger alligator.");
        print("He insults you about your size.");
        print("Do you 1) fight him or 2) ignore him?");
        userInput = getInput();
        if(userInput == "1"){
            print("You fight him and he bites you in the heart.");
            print("You slowly bleed out.");
            gameOver = true
        }
        if(userInput == "2"){
            print("You turn back from the alligator and ignore him.");
            print("You shouts at you its a female alligator.\nHer name is Taylor. She tells you it was");
            print("a good thing you ignored that alligator because he kills");
            print("everyone who talks to him.");
            print("You look at her to thank her...");
            location = "love"
        }
    }
    if(location == "family"){
        print("You and your wife Taylor have a home in the swamp where you were");
        print("born. You have a nest with 3 eggs that were layed a couple months");
        print("ago.");
        print("One day you were out getting food for your wife when you heard a scream.");
        print("It sounded like Taylor! You run to your nest the eggs are gone.");
        print("There is a trail of foot steps from the attackers.");
        print("What do you do 1) follow the trail or 2) comfort your wife?");
        userInput = getInput();
        if(userInput == "1"){
            location = "attackers"
        }
        if(userInput == "2"){
            print("You comfort your wife from the shock.");
            print("She then realizes because you couldn't defend your eggs she");
            print("leaves you.");
            gameOver = true
        }
    }
    if(location == "attackers"){
        print("You follow the trail and find the same beasts that locked you in");
        print("the zoo. You can't let your eggs end up in that place.");
        print("Do you 1) sneak around them or 2) fight them.");
        userInput = getInput();
        if(userInput == "2"){
            print("As you sneak around them you step in a trap getting your foot");
            print("stuck. You scream out in pain the attackers see you and capture");
            print("you too.");
            gameOver = true
        }
        if(userInput == "2"){
            print("You jump in front of the attackers and snarle.");
            print("They jump and run as fast as they can from you.");
            print("You pick up your eggs and bring them back to your wife.");
            location = "winGame"
        }
    }
    if(location == "winGame"){
        javaSleep(5000);
        print(spacer);
        print("You have beat the game!");
        print("THE END!");
        javaSleep(2000);
        gameOver = true
    }    
}
// GAME OVER ANIMATIONS
javaSleep(2500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||               -GAME-                 ||");
print("||               -OVER-                 ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||               -GAME-                 ||");
print("||               -OVER-                 ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||               -GAME-                 ||");
print("||               -OVER-                 ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||               -GAME-                 ||");
print("||               -OVER-                 ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print(" _______________________________________");              
print("||______________________________________||");               
print("||                                      ||");
print("||                                      ||");
print("||               -GAME-                 ||");
print("||               -OVER-                 ||");
print("||                                      ||");
print("||______________________________________||");
print("||______________________________________||");
print(userName);                                                      
javaSleep(500);
print(spacer);
print("             C  ");
javaSleep(50);
print(spacer);
print("             Cr  ");
javaSleep(50);
print(spacer);
print("             Cre  ");
javaSleep(50);
print(spacer);
print("             Crea  ");
javaSleep(50);
print(spacer);
print("             Creat  ");
javaSleep(50);
print(spacer);
print("             Create  ");
javaSleep(50);
print(spacer);
print("             Created  ");
javaSleep(50);
print(spacer);
print("             Created B  ");
javaSleep(50);
print(spacer);
print("             Created By  ");
javaSleep(50);
print(spacer);
print("             Created By:   ");
javaSleep(50);
print(spacer);
print("             Created By: L  ");
javaSleep(50);
print(spacer);
print("             Created By: La  ");
javaSleep(50);
print(spacer);
print("             Created By: Lac  ");
javaSleep(50);
print(spacer);
print("             Created By: Lach  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachl  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachla  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachlan   ");
javaSleep(50);
print(spacer);
print("             Created By: Lachlan M  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachlan Mo  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachlan Moo  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachlan Moor  ");
javaSleep(50);
print(spacer);
print("             Created By: Lachlan Moore  ");
javaSleep(1000);
print(spacer);
print("             Created By: Lachlan Moore        ");
print("             Tested By: Jath Ong &            ");
print("             Christian Kjaer                  ");
print("                                              ");
print("             2014 Square Rooted Watermelon    ");
print("                      Productions             ");
print("                  _______________________     ");
print("                 |     _____________          ");
print("                 |    \\\\ , , , , , //       ");
print("           \\     |     \\\\ ` ' ` ' //       ");
print("            \\    |      \\'._____.'/         ");
print("             \\___|       `'-----'`           ");
print("             Version 2.0                      "); 
print("             Over 1400 lines of code!         ");
javaSleep(2500);
print("");
print("             THANKS FOR PLAYING               ");

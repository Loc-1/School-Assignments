// Programmer's Name: Cheng
// Program Name: Code library to make life easier on students writing text based
//               programs with Rhino JavaScript engine running on Java Virtual Machine.
//               Does not work with any web browsers.
//////////////////////////////////////////////////////////////////////////

// Don't edit this file!

var getInput = (function(){
    var stdin = new java.io.BufferedReader(new java.io.InputStreamReader(java.lang.System['in']));
    return function(){return stdin.readLine();};
})();
var javaSleep = function(timeMilisec){java.lang.Thread.sleep(timeMilisec);}
var getWorkingDirectory = function(){return java.lang.System.getProperty("user.dir");}
var openFile = function(fileName){return new java.util.Scanner(new java.io.File(fileName));} // use hasNext() and nextLine() on result
var hasNextLine = function(openedFileObject){return openedFileObject.hasNext();}
var getNextLine = function(openedFileObject){return openedFileObject.nextLine();}

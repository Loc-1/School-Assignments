// Easter Egg Mini Game!!
// Only runs if name is Lachlan
// ANIMATIONS


javaSleep(1000);
print(spacer);
print("Loading");
javaSleep(250);
print(spacer);
print("Loading.");
javaSleep(250);
print(spacer);
print("Loading..");
javaSleep(250);
print(spacer);
print("Loading...");
javaSleep(250);
print(spacer);
print("Loading");
javaSleep(250);
print(spacer);
print("Loading.");
javaSleep(250);
print(spacer);
print("Loading..");
javaSleep(250);
print(spacer);
print("Loading...");
javaSleep(250);
print(spacer);
print("Loading");
javaSleep(250);
print(spacer);
print("Loading.");
javaSleep(250);
print(spacer);
print("Loading..");
javaSleep(250);
print(spacer);
print("Loading...");
javaSleep(250);
print(spacer);
print("Loading.");
javaSleep(250);


print(spacer);
print("W");
javaSleep(50);
print(spacer);
print("We");
javaSleep(50);
print(spacer);
print("Wel");
javaSleep(50);
print(spacer);
print("Welc");
javaSleep(50);
print(spacer);
print("Welco");
javaSleep(50);
print(spacer);
print("Welcom");
javaSleep(50);
print(spacer);
print("Welcome ");
javaSleep(50);
print(spacer);
print("Welcome L");
javaSleep(50);
print(spacer);
print("Welcome La");
javaSleep(50);
print(spacer);
print("Welcome Lac");
javaSleep(50);
print(spacer);
print("Welcome Lach");
javaSleep(50);
print(spacer);
print("Welcome Lachl");
javaSleep(50);
print(spacer);
print("Welcome Lachla");
javaSleep(50);
print(spacer);
print("Welcome Lachlan");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("I");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If t");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If th");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If thi");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this r");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this re");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this rea");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this real");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this reall");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this really");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this really i");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this really is");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this really is y");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this really is yo");
javaSleep(50);
print(spacer);
print("Welcome Lachlan!");
print("If this really is you!");
javaSleep(1200);

// Mini Game LOOP
var score = parseInt(0);
location = "miniGameStart"

while (gameOver == false){
    if(location == "miniGameStart"){
        javaSleep(1000);
        print(spacer);
        print("You have found the hidden easter egg!");
        print("");
        print("This is a quiz about Lachlan. I will ask you a question about Lachlan");
        print("if you get it right then you will get a point. If you get it");
        print("wrong you will lose this quiz and the real game!!! So anwser carefully.");
        javaSleep(6500);
        print(spacer);
        print("1st Question!");
        print("Where was Lachlan born?");
        print("1) Calgary 2) Sydney or 3) Perth?");
        userInput = getInput();
        if(userInput == "1"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "2"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "3"){
            print("Right!");
            score = score + 10
            print("Your score is: " + score);
            location = "question2"
        }
    }
    if(location == "question2"){
        print("2nd Question!");
        print("What is Lachlan's favorite food?");
        print("1) Steak 2) Fish or 3) Pancakes?");
        userInput = getInput();
        if(userInput == "1"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "3"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "2"){
            print("Right!");
            score = score + 10
            print("Your score is: " + score);
            location = "question3"
        }
    }
    if(location == "question3"){
        print("3rd Question!");
        print("What sport do you play?");
        print("1) Skiing 2) Football or 3) Tennis?");
        userInput = getInput();
        if(userInput == "1"){
            print("Right!");
            score = score + 10
            print("Your score is: " + score);
            location = "question4"
        }
        if(userInput == "3"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "2"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
    }
    if(location == "question4"){
        print("4th Question!");
        print("What does Lachlan's Dad call him?");
        print("1) Lochdown 2) Lachy or 3) Smelly?");
        userInput = getInput();
        if(userInput == "1"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "3"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "2"){
            print("Right!");
            score = score + 10
            print("Your score is: " + score);
            location = "question5"
        }
    }
    if(location == "question5"){
        print("5th and Final Question!");
        print("What is Lachlan's all time favorite game?");
        print("1) Leauge of Legends 2) The Legend of Zelda or 3) Pokemon?");
        userInput = getInput();
        if(userInput == "2"){
            print("Right!");
            score = score + 10
            print("Your score is: " + score);
            location = "miniGameEnd"
        }
        if(userInput == "1"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
        if(userInput == "3"){
            print("Wrong!");
            javaSleep(1000);
            gameOver = true
            
        }
    }
    if(location == "miniGameEnd"){
        print("You are Lachlan or you know him very well...");
        gameOver = true
    }
}

javaSleep(1555);

#!/bin/sh
APPDIR=$(dirname "$0")
cd "$APPDIR"
java -jar js.jar -f "myprogram.js"
$SHELL

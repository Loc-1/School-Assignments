var newPos;

var enemysInfo = {
    "enemy1" : enemy1Info,
    "enemy2" : enemy2Info,
    "enemy3" : enemy3Info,
    "enemy4" : enemy4Info,
    "enemy5" : enemy5Info,
    "boss"   : bossInfo
};
var splashScreen = {
   "width" : 480,
   "height" : 640,
   "id" : "splashscreen",
   "splash" : 0
};
var heart1Info = {
    "width"   : 35,
    "height"  : 36,
    "id"      : "heart1"
};
var heart2Info = {
    "width"   : 35,
    "height"  : 36,
    "id"      : "heart2"
};
var heart3Info = {
    "width"   : 35,
    "height"  : 36,
    "id"      : "heart3"
};
var triforceInfo = {
    "xspeed"  : 8,
    "yspeed"  : 3,
    "width"   : 40,
    "height"  : 32,
    "id"      : "triforce"
     
};
var triangleInfo = {
    "xspeed"  : 0,
    "yspeed"  : 1,
    "width"   : 40,
    "height"  : 31,
    "id"      : "triangle"
};
var watermelonInfo = {
    "xspeed"  : -7,
    "yspeed"  : -5,
    "width"   : 40,
    "height"  : 40,
    "id"      : "watermelon"
};

var rumbleInfo = {
    "x"       : 0,
    "y"       : 0,
    "xspeed"  : 5,
    "yspeed"  : 5,
    "width"   : 74,
    "height"  : 65,
    "id"      : "rumble1"  
};
var enemy1Info = {
    "xspeed"  : 0,
    "yspeed"  : 1,
    "width"   : 60,
    "height"  : 67.5,
    "id"      : "enemy1"
}
var enemy2Info = {
    "xspeed"  : 0,
    "yspeed"  : 2.5,
    "width"   : 52,
    "height"  : 67.5,
    "id"      : "enemy2"
}
var enemy3Info = {
    "xspeed"  : 0,
    "yspeed"  : 1.5,
    "width"   : 36,
    "height"  : 45,
    "id"      : "enemy3"
}
var enemy4Info = {
    "xspeed"  : 0,
    "yspeed"  : 0.4,
    "width"   : 28,
    "height"  : 28,
    "id"      : "enemy4"
}
var enemy5Info = {
    "xspeed"  : 0,
    "yspeed"  : 6,
    "width"   : 45,
    "height"  : 50,
    "id"      : "enemy5"
}
var bossInfo = {
    "xspeed"  : 0,
    "yspeed"  : 0.1,
    "width"   : 138.7,
    "height"  : 184,
    "id"      : "boss"
};
var linkInfo = {
    "xspeed"  : 7,
    "yspeed"  : 7,
    "x"       : 284,
    "y"       : 220,
    "width"   : 45,
    "height"  : 50,
    "stabHeight" : 80,
    "stabWidth" : 81,
    "moveRight" : 0,
    "moveLeft"  : 0,
    "moveDown"  : 0,
    "moveUp"    : 0,
    "stabRight" : 0,
    "stabLeft"  : 0,
    "stabDown"  : 0,
    "stabUp"    : 0,
    "stillRight" : 0,
    "stillLeft"  : 0,
    "stillDown"  : 0,
    "stillUp"    : 0,
    "holdingTriforce" : 0,
    "id"      : "linkStillForward",
    "state"   : "still"
};
var castleInfo = {
    "width"   : 640,
    "height"  : 111,
    "id"      : "castle"
};

var setup = function(){
    //Background 
    var backgroundAnim = newGQAnimation("img/Background.png");
    var castleAnim = newGQAnimation("img/Castle.png", 4 , 640 , 400 , $.gQ.ANIMATION_HORIZONTAL);
    var backgroundGroupName = "backgroundGroup";
    createGroupInPlayground(backgroundGroupName);
    createSpriteInGroup(backgroundGroupName, "background", {
        animation: backgroundAnim, 
        width: 640,
        height: 480
    });
    createSpriteInGroup(backgroundGroupName, "castle", {
        animation: castleAnim, 
        width: castleInfo["width"],
        height: castleInfo["height"]
    });
    spriteSetY("castle", 369);
    
    //Enemy Group 
    
    var enemy1Anim = newGQAnimation("img/Enemy1.png", 2 , 67.5 , 400 , $.gQ.ANIMATION_VERTICAL);
    var enemy2Anim = newGQAnimation("img/Enemy2.png", 2 , 67.5 , 400 , $.gQ.ANIMATION_VERTICAL);
    var enemy3Anim = newGQAnimation("img/Enemy3.png");
    var enemy4Anim = newGQAnimation("img/Enemy4.png");
    var enemy5Anim = newGQAnimation("img/Enemy5.png", 2 , 50 , 150 , $.gQ.ANIMATION_VERTICAL);
    var bossAnim = newGQAnimation("img/Boss.png", 3 , bossInfo["width"] , 600 , $.gQ.ANIMATION_HORIZONTAL);
    var enemyGroupName = "enemyGroup";
    createGroupInPlayground(enemyGroupName);
    createSpriteInGroup(enemyGroupName, "enemy1", {
        animation: enemy1Anim,
        width: enemy1Info["width"],
        height: enemy1Info['height']
    });
    spriteSetY("enemy1", 300 );
    spriteSetX("enemy1", 300 );
    createSpriteInGroup(enemyGroupName, "enemy2", {
        animation: enemy2Anim,
        width: enemy2Info["width"],
        height: enemy2Info["height"]
    });
    spriteSetY("enemy2", 300 );
    spriteSetX("enemy2", 360 );
    createSpriteInGroup(enemyGroupName, "enemy3", {
        animation: enemy3Anim,
        width: enemy3Info["width"],
        height: enemy3Info["height"]
    });
    spriteSetY("enemy3", 300 );
    spriteSetX("enemy3", 400 );
    createSpriteInGroup(enemyGroupName, "enemy4", {
        animation: enemy4Anim,
        width: enemy4Info["width"],
        height: enemy4Info["height"]
    });
    spriteSetY("enemy4", 300 );
    spriteSetX("enemy4", 272 );
    createSpriteInGroup(enemyGroupName, "enemy5", {
        animation: enemy5Anim,
        width: enemy5Info["width"],
        height: enemy5Info["height"]
    });
    spriteSetY("enemy5", 300 );
    spriteSetX("enemy5", 227 );
    createSpriteInGroup(enemyGroupName, "boss", {
        animation: bossAnim,
        width: bossInfo["width"],
        height: bossInfo["height"]
    });
    spriteSetY("boss", -184 );
    spriteSetX("boss", 540 );
    
    //Power Up Group 
    
    var watermelonAnim = newGQAnimation("img/Watermelon.png");
    var triangleAnim = newGQAnimation("img/Triangle.png");
    var triforceAnim = newGQAnimation("img/Triforce.png", 3 , 40 , 1000 , $.gQ.ANIMATION_HORIZONTAL);
    var heartAnim = newGQAnimation("img/Heart.png");
    var powerUpGroupName = "powerUpGroup";
    createGroupInPlayground(powerUpGroupName);
    createSpriteInGroup(powerUpGroupName, "watermelon", {
        animation: watermelonAnim,
        width: watermelonInfo["width"],
        height: watermelonInfo["height"]
    });
    spriteSetY("watermelon", 34 );
    spriteSetX("watermelon", 100 );
    createSpriteInGroup(powerUpGroupName, "triangle", {
        animation: triangleAnim,
        width: triangleInfo["width"],
        height: triangleInfo["height"]
    });
    spriteSetY("triangle", 500);
    spriteSetX("triangle", Math.floor((Math.random()* 600) +1) );
    createSpriteInGroup(powerUpGroupName, "triforce", {
        animation: triforceAnim,
        width: triforceInfo["width"],
        height: triforceInfo["height"]
    });
    spriteSetY("triforce", 440 );
    spriteSetX("triforce", 600 );
    createSpriteInGroup(powerUpGroupName, "heart1", {
        animation: heartAnim,
        width: heart1Info["width"],
        height: heart1Info["height"]
    });
    spriteSetY("heart1", 440 );
    spriteSetX("heart1", 0 );
    createSpriteInGroup(powerUpGroupName, "heart2", {
        animation: heartAnim,
        width: heart2Info["width"],
        height: heart2Info["height"]
    });
    spriteSetY("heart2", 440 );
    spriteSetX("heart2", 37 );
    createSpriteInGroup(powerUpGroupName, "heart3", {
        animation: heartAnim,
        width: heart3Info["width"],
        height: heart3Info["height"]
    });
    spriteSetY("heart3", 440 );
    spriteSetX("heart3", 75 );
    
    
    //LINK Sprites
    linkInfo["moveRight"] = newGQAnimation("img/Linkwalkright.png", 4 , 50 , 200 , $.gQ.ANIMATION_VERTICAL);
    linkInfo["moveLeft"] = newGQAnimation("img/Linkwalkleft.png", 4 , 50 , 200 , $.gQ.ANIMATION_VERTICAL);
    linkInfo["moveUp"] = newGQAnimation("img/Linkwalkforward.png", 4 , 50 , 200 , $.gQ.ANIMATION_VERTICAL);
    linkInfo["moveDown"] = newGQAnimation("img/Linkwalkbackward.png", 4 , linkInfo["height"] , 200 , $.gQ.ANIMATION_VERTICAL);
    linkInfo["stabDown"] = newGQAnimation("img/Linkstabbackward.png");
    linkInfo["stabRight"] = newGQAnimation("img/Linkstabright.png");
    linkInfo["stabLeft"] = newGQAnimation("img/Linkstableft.png");
    linkInfo["stabUp"] = newGQAnimation("img/Linkstabforward.png");
    linkInfo["stillRight"] = newGQAnimation("img/LinkStillright.png");
    linkInfo["stillLeft"] = newGQAnimation("img/LinkStillleft.png");
    linkInfo["stillDown"] = newGQAnimation("img/LinkStillbackward.png");
    linkInfo["stillUp"] = newGQAnimation("img/LinkStillforward.png");
    linkInfo["holdingTriforce"] = newGQAnimation("img/LinkHoldingTriforce.png"); // For Triforce Power Up
    var linkGroupName = "linkGroup";
    createGroupInPlayground(linkGroupName);
    createSpriteInGroup(linkGroupName, "linkStillForward", {
        animation: linkInfo["stillDown"], 
        width: linkInfo["width"],
        height: linkInfo["height"]
    });
    spriteSetX("linkStillForward", linkInfo["x"]);
    spriteSetY("linkStillForward", linkInfo["y"]);
       
}; // end of setup() function. Notice the braces match!


var moveSprite = function(spriteInfo){
    newPos = spriteGetY(spriteInfo["id"]) + spriteInfo["yspeed"];
    if(newPos > PLAYGROUND_HEIGHT){
        newPos = -spriteInfo["height"];
    }
    if(newPos < -spriteInfo["height"]){
        newPos = PLAYGROUND_HEIGHT;
    }
    spriteSetY(spriteInfo["id"], newPos);
    
    newPos = spriteGetX(spriteInfo["id"]) - spriteInfo["xspeed"];
    if(newPos > PLAYGROUND_WIDTH){
        newPos = -spriteInfo["width"];
    }
    if(newPos < -spriteInfo["width"]){
        newPos = PLAYGROUND_WIDTH;
    }
    spriteSetX(spriteInfo["id"], newPos );  
};


var bounceSprite = function(spriteInfo){
    newPos = spriteGetY(spriteInfo["id"]) + spriteInfo["yspeed"];
    if(newPos > PLAYGROUND_HEIGHT - spriteInfo["height"]){
        spriteInfo["yspeed"] = spriteInfo["yspeed"] * -1;
    }else if(newPos < 0){
        spriteInfo["yspeed"] = spriteInfo["yspeed"] * -1;
    }
    spriteSetY(spriteInfo["id"], newPos);
    
    newPos = spriteGetX(spriteInfo["id"]) + spriteInfo["xspeed"];
    if(newPos > PLAYGROUND_WIDTH - spriteInfo["width"]){
        spriteInfo["xspeed"] = spriteInfo["xspeed"] * -1;
    }else if(newPos < 0){
        spriteInfo["xspeed"] = spriteInfo["xspeed"] * -1;
    }
    spriteSetX(spriteInfo["id"], newPos );
};


var moveByKeyboard = function(spriteInfo){
   
   var areaOfMovement = 111
   
   if(getKeyState(65)){//a
        spriteInfo["x"] = spriteInfo["x"] - spriteInfo["xspeed"];
        if(spriteInfo["state"] != "moveLeft"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["moveLeft"]);
            spriteSetHeight(spriteInfo["id"], spriteInfo["height"]);
            spriteSetWidth(spriteInfo["id"], spriteInfo["width"]);
        }
        spriteInfo["state"] = "moveLeft"
        
    }else if(getKeyState(68)){//d
        spriteInfo["x"] = spriteInfo["x"] + spriteInfo["xspeed"];
        if(spriteInfo["state"] != "moveRight"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["moveRight"]);
            spriteSetHeight(spriteInfo["id"], spriteInfo["height"]);
            spriteSetWidth(spriteInfo["id"], spriteInfo["width"]);
        }
        spriteInfo["state"] = "moveRight"
        
    }else if(getKeyState(83)){//s
        spriteInfo["y"] = spriteInfo["y"] + spriteInfo["yspeed"];
        if(spriteInfo["state"] != "moveDown"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["moveDown"]);
            spriteSetHeight(spriteInfo["id"], spriteInfo["height"]);
            spriteSetWidth(spriteInfo["id"], spriteInfo["width"]);
        }
        spriteInfo["state"] = "moveDown"
        
    }else if(getKeyState(87)){//w
        spriteInfo["y"] = spriteInfo["y"] - spriteInfo["yspeed"];
        if(spriteInfo["state"] != "moveUp"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["moveUp"]);
            spriteSetHeight(spriteInfo["id"], spriteInfo["height"]);
            spriteSetWidth(spriteInfo["id"], spriteInfo["width"]);
        }
        spriteInfo["state"] = "moveUp"
    }
    
    
    if(getKeyState(32)){//spacebar
        if(spriteInfo["state"] == "stillUp"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stabUp"]);
            spriteSetHeight(spriteInfo["id"], spriteInfo["stabHeight"]);
            spriteInfo["state"] = "stabUp"  
        }
        if(spriteInfo["state"] == "stillDown"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stabDown"]);
            spriteSetHeight(spriteInfo["id"], spriteInfo["stabHeight"]);
            spriteInfo["state"] = "stabDown"  
        }
        if(spriteInfo["state"] == "stillRight"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stabRight"]);
            spriteSetWidth(spriteInfo["id"], spriteInfo["stabWidth"]);
            spriteInfo["state"] = "stabRight"  
        }
        if(spriteInfo["state"] == "stillLeft"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stabLeft"]);
            spriteSetWidth(spriteInfo["id"], spriteInfo["stabWidth"]);
            spriteInfo["state"] = "stabLeft"  
        }
    }
    
    if(spriteInfo["id"] == areaOfMovement){
        spriteInfo["y"] = 0
        spriteInfo["x"] = 0
    }
    
    
    spriteSetX(spriteInfo["id"], spriteInfo["x"] );
    spriteSetY(spriteInfo["id"], spriteInfo["y"] );
    
    
    if(!getKeyState(65)){//a
        if(spriteInfo["state"] == "moveLeft"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stillLeft"]);
            spriteInfo["state"] = "stillLeft"
        }
    }
    if(!getKeyState(68)){//d
        if(spriteInfo["state"] == "moveRight"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stillRight"]);
            spriteInfo["state"] = "stillRight"
        }
    }
    if(!getKeyState(83)){//s
        if(spriteInfo["state"] == "moveDown"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stillDown"]);
            spriteInfo["state"] = "stillDown"
        }
    }
    if(!getKeyState(87)){//w
        if(spriteInfo["state"] == "moveUp"){
            spriteSetAnimation(spriteInfo["id"], spriteInfo["stillUp"]);
            spriteInfo["state"] = "stillUp"
        }
    }
};


var linkTriangleCollision = function(){
    spriteSetY("triangle", 480);
    spriteSetX("triangle", Math.floor((Math.random()* 600) +1));
};


var linkWatermelonCollision = function(){
    if(linkInfo["xspeed"] <= 21){
        linkInfo["xspeed"] = linkInfo["xspeed"] + linkInfo["xspeed"];
        linkInfo["yspeed"] = linkInfo["yspeed"] + linkInfo["yspeed"];  
    }// Need to make a timer for how long the power up lasts
    spriteSetY("watermelon", Math.floor((Math.random()* 440) +1));
    spriteSetX("watermelon", Math.floor((Math.random()* 600) +1));
};


var draw = function(){
    moveSprite(bossInfo);
    moveSprite(enemy1Info);
    moveSprite(enemy2Info);
    moveSprite(enemy3Info);
    moveSprite(enemy4Info);
    moveSprite(enemy5Info);
    moveSprite(triangleInfo)
    bounceSprite(watermelonInfo);     
    moveByKeyboard(linkInfo); 
    forEachSpriteSpriteCollisionDo(linkInfo["id"], triangleInfo["id"], linkTriangleCollision);
    forEachSpriteSpriteCollisionDo(linkInfo["id"], watermelonInfo["id"], linkWatermelonCollision);
}; // end of draw() function. Notice the braces match!

package cs20models;

public class MyCalculator {

    private String operation;
    private int result, number, saveNum;

    public MyCalculator() {
        this.operation = "";
        this.result = 0;
        this.number = 0;
        this.saveNum = 0;
    }

    public String getOperation() {
        return operation;
    }

    public void setOperation(String s) {
        this.operation = s;
    }

    public int getNumber() {
        return number;
    }

    public void updateNumber(int num) {
        number = (number * 10) + num;
    }

    public int getResults() {
        if (this.operation.equals("+")) {
            this.result = this.saveNum + this.number;
            return this.result;
        }
        if (this.operation.equals("-")) {
            this.result = this.saveNum - this.number;
            return this.result;
        }
        if (this.operation.equals("*")) {
            this.result = this.saveNum * this.number;
            return this.result;
        }
        if (this.operation.equals("/")) {
            this.result = this.saveNum / this.number;
            return this.result;
        }
        if (this.operation.equals("")) {
            return number;
        }
        return 0;
    }
    
    public void saveNum() {
        this.saveNum = this.number;
    }

    public void clearDisplay() {
        this.number = 0;
        this.result = 0;
    }

    public int getSaveNum() {
        return saveNum;
    }
    
    public void saveResult(){
        this.saveNum = this.result;
    }

    public void clearAll() {
        this.operation = "";
        this.result = 0;
        this.number = 0;
        this.saveNum = 0;
    }

}

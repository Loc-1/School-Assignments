package cs20viewcontroller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * ViewUserActions is a class that contains actions users can trigger.
 *
 *
 */
public class ViewUserActions extends ViewOutputs {

    private class AddNumAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            if (!MyCalc.getOperation().equals("")) {
                MyCalc.saveResult();
                MyCalc.clearDisplay();
                updateResult();
            } else {
                MyCalc.setOperation("+");
                MyCalc.saveNum();
                MyCalc.clearDisplay();
                updateDisplay();
            }
        }
    }

    private class SubtractNumAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.setOperation("-");
            MyCalc.saveNum();
            MyCalc.clearDisplay();
            updateDisplay();
        }
    }

    private class DivideNumAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.setOperation("/");
            MyCalc.saveNum();
            MyCalc.clearDisplay();
            updateDisplay();
        }
    }

    private class MultiplyNumAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.setOperation("*");
            MyCalc.saveNum();
            MyCalc.clearDisplay();
            updateDisplay();
        }
    }

    private class EqualNumAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            updateResult();
        }
    }

    private class Num0Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(0);
            updateDisplay();
        }
    }

    private class Num1Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(1);
            updateDisplay();
        }
    }

    private class Num2Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(2);
            updateDisplay();
        }
    }

    private class Num3Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(3);
            updateDisplay();
        }
    }

    private class Num4Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(4);
            updateDisplay();
        }
    }

    private class Num5Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(5);
            updateDisplay();
        }
    }

    private class Num6Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(6);
            updateDisplay();
        }
    }

    private class Num7Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(7);
            updateDisplay();
        }
    }

    private class Num8Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(8);
            updateDisplay();
        }
    }

    private class Num9Action implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.updateNumber(9);
            updateDisplay();
        }
    }

    private class ClearNumAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {
            MyCalc.clearAll();
            updateResult();
        }
    }

    private class PointAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent ae) {

        }
    }

    /*
     * ViewUserActions constructor used for wiring user actions to GUI elements
     */
    public ViewUserActions() {

//        copyTextButton.addActionListener(new AddNumAction());
        button0.addActionListener(new Num0Action());
        button1.addActionListener(new Num1Action());
        button2.addActionListener(new Num2Action());
        button3.addActionListener(new Num3Action());
        button4.addActionListener(new Num4Action());
        button5.addActionListener(new Num5Action());
        button6.addActionListener(new Num6Action());
        button7.addActionListener(new Num7Action());
        button8.addActionListener(new Num8Action());
        button9.addActionListener(new Num9Action());
        add.addActionListener(new AddNumAction());
        subtract.addActionListener(new SubtractNumAction());
        divide.addActionListener(new DivideNumAction());
        times.addActionListener(new MultiplyNumAction());
        equals.addActionListener(new EqualNumAction());
        clear.addActionListener(new ClearNumAction());
        point.addActionListener(new PointAction());
    }
}